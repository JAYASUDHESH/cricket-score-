# Cricket-Score-Predictor
Cricket match score prediction using Machine learning algorithms: Linear Regression &amp; Random Forest.
